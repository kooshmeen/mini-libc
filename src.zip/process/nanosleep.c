#include <unistd.h>
#include <internal/syscall.h>
#include <time.h>

//source : inspired by musl.libc implementation


int nanosleep(const struct timespec *req, struct timespec *rem) {
    int ret = syscall(__NR_clock_nanosleep, CLOCK_REALTIME, 0, req, rem);
    return ret;
}